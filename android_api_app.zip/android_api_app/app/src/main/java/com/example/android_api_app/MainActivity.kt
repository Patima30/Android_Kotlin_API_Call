package com.example.android_api_app

import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.android.volley.Request
import com.android.volley.RequestQueue
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley

class MainActivity : AppCompatActivity() {
    var userList = arrayListOf<User>()
    //Les actualités liées à Tesla
    private val apiNews = "https://reqres.in/api/users"
    var recyclerView: RecyclerView? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        recyclerView = findViewById(R.id.recyclerView)

        val reqQueue : RequestQueue = Volley.newRequestQueue(this)
        val request = JsonObjectRequest(Request.Method.GET, apiNews,null,{res->
            Log.d("Volley Sample",res.getString("page"))

            val jsonArray = res.getJSONArray("data")
            for(i in 0 until jsonArray.length()){
                val jsonObj = jsonArray.getJSONObject(i)
                val user = User(
                    jsonObj.getInt("id"),
                    jsonObj.getString("email"),
                    jsonObj.getString("first_name"),
                    jsonObj.getString("last_name"),
                    jsonObj.getString("avatar"),
                )

                userList.add(user)
                Log.d("Volley Sample",userList.toString())

            }
            recyclerView?.layoutManager = LinearLayoutManager(this)
            recyclerView?.adapter = UserAdapter(userList)

        },{ err ->
            Log.d("Fail",err.message.toString())
        })
        reqQueue.add(request)

    }
}



data class User(
    var id: Int,
    var email: String,
    var first_name: String,
    var last_name: String,
    var avatar: String
)